#define __strtol strtoul
#define __strtol_t unsigned long int
#define __xstrtol xstrtoul
#include "xstrtol.c"

/* $Id: xstrtoul.c,v 1.1 2004/02/02 07:16:25 alank Exp $ */
